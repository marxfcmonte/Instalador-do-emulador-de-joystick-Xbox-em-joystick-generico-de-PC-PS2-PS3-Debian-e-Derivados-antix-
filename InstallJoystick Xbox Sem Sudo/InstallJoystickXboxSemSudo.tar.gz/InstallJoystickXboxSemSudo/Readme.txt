Execute o arquivo "InstallJoystickXbox360SemSudoInit.sh" com "./InstallJoystickXbox360SemSudoInit.sh", 
quando for solicitado a senha do "sudo", insira.

O executável instalará as dependências necessárias.
