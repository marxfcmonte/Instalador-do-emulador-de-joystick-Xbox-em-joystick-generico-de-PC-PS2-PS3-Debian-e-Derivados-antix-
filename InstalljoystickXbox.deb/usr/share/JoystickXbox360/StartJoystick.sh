#!/bin/bash

pkill xboxdrv &
sleep 5
i=0
while true
do
	udevadm info -a -n /dev/input/event$i > /usr/share/JoystickXbox360/joystick.log
	if ! [ "$(cat /usr/share/JoystickXbox360/joystick.log)" ]; then
		clear
		echo -e "\nPorta do joystick não localizada..."
		echo -e "Joystick Xbox 360\033[31;1m falhou\033[0m..." >		 /usr/share/JoystickXbox360/joystickxbox360.conf
		exit 1
	fi
	udevadm info -a -n /dev/input/event$i | grep -q "Joystick"
	if [ "$?" = "0" ]; then
		echo -e "\nPorta do joystick localizada..."
		echo -e "Joystick Xbox 360\033[32;1m reiniciado\033[0m..." >		 /usr/share/JoystickXbox360/joystickxbox360.conf
		jost=$i
		break
	fi
	i=$[ i + 1 ]
done
joystickconf="$(cat /usr/share/JoystickXbox360/xboxdrv.conf)"
xboxdrv --evdev /dev/input/event$jost $joystickconf > /tmp/joystick.log &
sleep 5
i=0
while true
do
	udevadm info -a -n /dev/input/event$i > /usr/share/JoystickXbox360/joystick.log
	if ! [ "$(cat /usr/share/JoystickXbox360/joystick.log)" ]; then
		clear
		echo -e "Porta do joystick Xbox 360 emulado não localizada..."
		echo -e "Joystick Xbox 360\033[31;1m falhou\033[0m..." >		 /usr/share/JoystickXbox360/joystickxbox360.conf
		exit 1
	fi
	udevadm info -a -n /dev/input/event$i | grep -q "Microsoft X-Box 360 pad"
	if [ "$?" = "0" ]; then
		echo "Porta do joystick Xbox 360 emulado localizada..."
		echo -e "Joystick Xbox 360\033[32;1m iniciado\033[0m..." >		 /usr/share/JoystickXbox360/joystickxbox360.conf
		jost1=$i
		break
	fi
	i=$[ i + 1 ]
done
chmod 775 /dev/input/event$jost1
sleep 2

exit 0

