#!/bin/bash

display_principal(){
	cont="$[${#texto} + 4]"
	dialog --infobox "$texto" 3 $cont
	sleep 3
	clear
}

pasta_joystick=/usr/share/JoystickXbox360

pkill xboxdrv &
sleep 5
i=0
while true
do
	udevadm info -a -n /dev/input/event$i > $pasta_joystick/joystick.log
	if ! [ "$(cat $pasta_joystick/joystick.log)" ]; then
		clear
		texto="Porta do joystick não localizada..."
		display_principal
		echo -e "Joystick Xbox 360\033[31;1m falhou\033[0m..." > $pasta_joystick/joystickxbox360.conf
		exit 1
	fi
	udevadm info -a -n /dev/input/event$i | grep -q "Joystick"
	if [ "$?" = "0" ]; then
		echo -e "\nPorta do joystick localizada..."
		echo -e "Joystick Xbox 360\033[32;1m reiniciado\033[0m..." > $pasta_joystick/joystickxbox360.conf
		jost=$i
		break
	fi
	i=$[ i + 1 ]
done
joystickconf="$(cat $pasta_joystick/xboxdrv.conf)"
xboxdrv --evdev /dev/input/event$jost $joystickconf > /tmp/joystick.log &
sleep 5
i=0
while true
do
	udevadm info -a -n /dev/input/event$i > $pasta_joystick/joystick.log
	if ! [ "$(cat /usr/share/JoystickXbox360/joystick.log)" ]; then
		clear
		texto="Porta do joystick Xbox 360 emulado não localizada..."
		display_principal
		echo -e "Joystick Xbox 360\033[31;1m falhou\033[0m..." > $pasta_joystick/joystickxbox360.conf
		exit 1
	fi
	udevadm info -a -n /dev/input/event$i | grep -q "Microsoft X-Box 360 pad"
	if [ "$?" = "0" ]; then
		echo "Porta do joystick Xbox 360 emulado localizada..."
		echo -e "Joystick Xbox 360\033[32;1m reiniciado\033[0m..." > $pasta_joystick/joystickxbox360.conf
		jost1=$i
		sleep 3
		break
	fi
	i=$[ i + 1 ]
done
chmod 775 /dev/input/event$jost1
texto="\Z1AGUARDE...\Zn PARA O JOYSTICK SER RECONHECIDO."
cont="$[${#texto} + 4]"
dialog --colors --nocancel --pause "$texto" 8 $cont 60
clear

exit 0

