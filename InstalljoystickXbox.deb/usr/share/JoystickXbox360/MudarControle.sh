#!/bin/bash

display_principal(){
	cont="$[${#texto} + 4]"
	dialog --infobox "$texto" 3 $cont
	sleep 3
	clear
}

cancelar_principal(){
	if [ "$validacao" = "1" ]; then
		texto="Cancelado pelo usuário."
		display_principal
		sudo chown root:root $pasta_joystick/*.log
		sudo chown root:root $pasta_joystick/*.conf
		sudo service joystickxbox360 restart 
		exit 0
	fi
}

pasta_joystick=/usr/share/JoystickXbox360

while true
do
	senha=$(dialog --title "AUTORIZAÇÃO" --passwordbox "Digite a senha (SUDO):" 8 40 --stdout)
	validacao="$?"
	cancelar_principal
	if [ -z "$senha" ]; then
		dialog --colors --title "\Zr\Z1  ERRO                               \Zn" --infobox "A senha (SUDO) não foi digitada." 3 37
		sleep 2
		clear
	else
		break
	fi
done
clear
echo $senha|sudo -S -p "" chown $USER:$USER $pasta_joystick/*.log
sudo pkill xboxdrv &
sudo touch $pasta_joystick/joystick1.log
sudo chown $USER:$USER $pasta_joystick/joystick1.log
sudo chown $USER:$USER $pasta_joystick/*.conf
sudo touch $pasta_joystick/controle1.conf
sudo chown $USER:$USER $pasta_joystick/controle1.conf
sudo touch $pasta_joystick/controle2.conf
sudo chown $USER:$USER $pasta_joystick/controle2.conf
sleep 5
i=0
while true
do
	udevadm info -a -n /dev/input/event$i > $pasta_joystick/joystick.log
	if ! [ "$(cat $pasta_joystick/joystick.log)" ]; then
		clear
		texto="Porta do joystick não localizada..."
		display_principal
		echo -e "Joystick Xbox 360\033[31;1m falhou\033[0m..." > $pasta_joystick/joystickxbox360.conf
		exit 1
	fi
	udevadm info -a -n /dev/input/event$i | grep -q "Joystick"
	if [ "$?" = "0" ]; then
		texto="Porta do joystick localizada..."
		display_principal
		echo -e "Joystick Xbox 360\033[32;1m iniciado\033[0m..." > $pasta_joystick/joystickxbox360.conf
		jost=$i
		sudo evtest /dev/input/event$i > $pasta_joystick/controle.conf & sudo pkill evtest
		cat $pasta_joystick/controle.conf | grep -n exit | cut -d ":" -f1 > $pasta_joystick/numero.conf
		numero="$(cat /usr/share/JoystickXbox360/numero.conf)"
		sed -n "1,$numero p" $pasta_joystick/controle.conf >  $pasta_joystick/controle2.conf
		cat $pasta_joystick/controle2.conf | grep ABS_ | cut -d "(" -f2 > $pasta_joystick/controle1.conf
		cat $pasta_joystick/controle2.conf | grep BTN_ | cut -d "(" -f2 >> $pasta_joystick/controle1.conf
		cat $pasta_joystick/controle1.conf | grep ")" | cut -d ")" -f1 > $pasta_joystick/controle.conf
		sudo rm $pasta_joystick/controle1.conf $pasta_joystick/controle2.conf
		var=($(cat $pasta_joystick/controle.conf))
		sleep 3
		clear
		break
	fi
	i=$[ i + 1 ]
done
sleep 5
clear
texto="PARA CONFIGURAÇÃO COM ANALÓGICOS COM SENTIDO INVERTIDO"
cont="$[${#texto} + 10]"
xbox=$(dialog --title "MENU" --menu "ESCOLHA A CONFIGURAÇÃO DESEJADA\n(SETAS PARA ESCOLHER E ENTER PARA CONFIRMAR)" 10 $cont 4 "1" "PARA CONFIGURAÇÃO PADRÃO" "2" "PARA CONFIGURAÇÃO COM ANALÓGICOS COM SENTIDO INVERTIDO" --stdout)
clear
case $xbox in
	1)
	cat <<EOF > $pasta_joystick/status.conf
configuração padrão...
EOF
	cat <<EOF > $pasta_joystick/xboxdrv.conf
--evdev-absmap ${var[0]}=x1,${var[1]}=y1,${var[2]}=x2,${var[3]}=y2,${var[4]}=dpad_x,${var[5]}=dpad_y --axismap X1=X1,X2=X2,-Y1=Y1,-Y2=Y2,DPAD_X=DPAD_X,DPAD_Y=DPAD_Y --evdev-keymap ${var[6]}=y,${var[7]}=b,${var[8]}=a,${var[9]}=x,${var[10]}=lb,${var[11]}=rb,${var[12]}=lt,${var[13]}=rt,${var[14]}=back,${var[15]}=start,${var[16]}=tl,${var[17]}=tr --mimic-xpad --silent
EOF
	;;
	2)
	cat <<EOF > $pasta_joystick/status.conf
analógicos com sentido invertido...
EOF
	cat <<EOF > $pasta_joystick/xboxdrv.conf
--evdev-absmap ${var[0]}=x1,${var[1]}=y1,${var[2]}=x2,${var[3]}=y2,${var[4]}=dpad_x,${var[5]}=dpad_y --axismap X1=X1,X2=X2,Y1=Y1,Y2=Y2,DPAD_X=DPAD_X,DPAD_Y=DPAD_Y --evdev-keymap ${var[6]}=y,${var[7]}=b,${var[8]}=a,${var[9]}=x,${var[10]}=lb,${var[11]}=rb,${var[12]}=lt,${var[13]}=rt,${var[14]}=back,${var[15]}=start,${var[16]}=tl,${var[17]}=tr --mimic-xpad --silent
EOF
	;;
	*)
	texto="Configuração cancelada..."
	display_principal
	sudo chown root:root $pasta_joystick/*.log
	sudo chown root:root $pasta_joystick/*.conf
	sudo service joystickxbox360 restart 
	exit 0
	;;
esac
configuracao="opção $xbox selecionada: $(cat $pasta_joystick/status.conf)"
cont="$[${#configuracao} + 4]"
joystickconf="$(cat $pasta_joystick/xboxdrv.conf)"
clear
dialog --infobox "Configuração sendo iniciada...\n$configuracao" 4 $cont
sudo chmod 664 /dev/input/event$jost
sudo xboxdrv --evdev /dev/input/event$jost $joystickconf > $pasta_joystick/joystick1.log &
sudo rm $pasta_joystick/joystick1.log
sleep 5
i=0
while true
do
	udevadm info -a -n /dev/input/event$i > $pasta_joystick/joystick.log
	if ! [ "$(cat $pasta_joystick/joystick.log)" ]; then
		clear
		texto="Porta do joystick Xbox 360 emulado não localizada..."
		display_principal
		echo -e "Joystick Xbox 360\033[31;1m falhou\033[0m..." > $pasta_joystick/joystickxbox360.conf
		exit 1
	fi
	udevadm info -a -n /dev/input/event$i | grep -q "Microsoft X-Box 360 pad"
	if [ "$?" = "0" ]; then
		texto="Porta do joystick Xbox 360 emulado localizada..."
		display_principal
		echo -e "Joystick Xbox 360\033[32;1m iniciado\033[0m..." > $pasta_joystick/joystickxbox360.conf
		jost1=$i
		break
	fi
	i=$[ i + 1 ]
done
sudo chown root:root $pasta_joystick/*.log
sudo chown root:root $pasta_joystick/*.conf
sudo chmod 664 /dev/input/event$jost1
sleep 6
clear
sudo service joystickxbox360 status
sleep 6
clear
dialog --nocancel --pause "Teste o Joystick Xbox 360 emulado no AntiMicroX caso\n
os analógicos ficarem com sentido invertido, use o aplicativo 'Muda a configuração do joystick Xbox 360': \n
opção escolhida agora - Opção $xbox." 11 65 20

reset
antimicrox

exit 0

