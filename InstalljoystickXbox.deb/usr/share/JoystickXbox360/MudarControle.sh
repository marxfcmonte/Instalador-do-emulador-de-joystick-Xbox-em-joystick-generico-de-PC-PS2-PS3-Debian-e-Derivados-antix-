#!/bin/bash

senha=$(dialog --title "AUTORIZAÇÃO" --passwordbox "Digite a senha (SUDO):" 8 40 --stdout)
if [ -z "$senha" ]; then
	dialog --title "ERRO" --infobox "A senha (SUDO) não foi digitada." 3 40
	sleep 3
	clear
	exit 1
fi
clear
echo $senha|sudo -S -p "" chown marxfcmonte:marxfcmonte /usr/share/JoystickXbox360/*.log
sudo pkill xboxdrv &
sudo touch /usr/share/JoystickXbox360/joystick1.log
sudo chown marxfcmonte:marxfcmonte /usr/share/JoystickXbox360/joystick1.log
sudo chown marxfcmonte:marxfcmonte /usr/share/JoystickXbox360/*.conf
sudo touch /usr/share/JoystickXbox360/controle1.conf
sudo chown marxfcmonte:marxfcmonte /usr/share/JoystickXbox360/controle1.conf
sudo touch /usr/share/JoystickXbox360/controle2.conf
sudo chown marxfcmonte:marxfcmonte /usr/share/JoystickXbox360/controle2.conf
sleep 5
i=0
while true
do
	udevadm info -a -n /dev/input/event$i > /usr/share/JoystickXbox360/joystick.log
	if ! [ "$(cat /usr/share/JoystickXbox360/joystick.log)" ]; then
		clear
		texto="Porta do joystick não localizada..."
		cont="$[${#texto} + 4]"
		dialog --infobox "$texto" 3 $cont
		sleep 3
		clear
		echo -e "Joystick Xbox 360\033[31;1m falhou\033[0m..." >		  /usr/share/JoystickXbox360/joystickxbox360.conf
		exit 1
	fi
	udevadm info -a -n /dev/input/event$i | grep -q "Joystick"
	if [ "$?" = "0" ]; then
		dialog --infobox "Porta do joystick localizada..." 3 35
		echo -e "Joystick Xbox 360\033[32;1m iniciado\033[0m..." >		  /usr/share/JoystickXbox360/joystickxbox360.conf
		jost=$i
		sudo evtest /dev/input/event$i > /usr/share/JoystickXbox360/controle.conf & sudo pkill evtest
		cat /usr/share/JoystickXbox360/controle.conf | grep -n exit | cut -d ":" -f1 > /usr/share/JoystickXbox360/numero.conf
		numero=$(cat /usr/share/JoystickXbox360/numero.conf)
		sed -n "1,$numero p" /usr/share/JoystickXbox360/controle.conf >  /usr/share/JoystickXbox360/controle2.conf
		cat /usr/share/JoystickXbox360/controle2.conf | grep ABS_ | cut -d "(" -f2 > /usr/share/JoystickXbox360/controle1.conf
		cat /usr/share/JoystickXbox360/controle2.conf | grep BTN_ | cut -d "(" -f2 >> /usr/share/JoystickXbox360/controle1.conf
		cat /usr/share/JoystickXbox360/controle1.conf | grep ")" | cut -d ")" -f1 > /usr/share/JoystickXbox360/controle.conf
		rm /usr/share/JoystickXbox360/controle1.conf /usr/share/JoystickXbox360/controle2.conf
		var=($(cat /usr/share/JoystickXbox360/controle.conf))
		sleep 3
		clear
		break
	fi
	i=$[ i + 1 ]
done
sleep 5
clear
texto="PARA CONFIGURAÇÃO COM ANALÓGICOS COM SENTIDO INVERTIDO"
cont="$[${#texto} + 10]"
xbox=$(dialog --title "MENU" --menu "ESCOLHA A CONFIGURAÇÃO DESEJADA\n(SETAS PARA ESCOLHER E ENTER PARA CONFIRMAR)" 10 $cont 4 "1" "PARA CONFIGURAÇÃO PADRÃO" "2" "PARA CONFIGURAÇÃO COM ANALÓGICOS COM SENTIDO INVERTIDO" --stdout)
clear
case $xbox in
	1)
	cat <<EOF > /usr/share/JoystickXbox360/status.conf
configuração padrão...
EOF
	cat <<EOF > /usr/share/JoystickXbox360/xboxdrv.conf
--evdev-absmap ${var[0]}=x1,${var[1]}=y1,${var[2]}=x2,${var[3]}=y2,${var[4]}=dpad_x,${var[5]}=dpad_y --axismap X1=X1,X2=X2,-Y1=Y1,-Y2=Y2,DPAD_X=DPAD_X,DPAD_Y=DPAD_Y --evdev-keymap ${var[6]}=y,${var[7]}=b,${var[8]}=a,${var[9]}=x,${var[10]}=lb,${var[11]}=rb,${var[12]}=lt,${var[13]}=rt,${var[14]}=back,${var[15]}=start,${var[16]}=tl,${var[17]}=tr --mimic-xpad --silent
EOF
	;;
	2)
	cat <<EOF > /usr/share/JoystickXbox360/status.conf
analógicos com sentido invertido...
EOF
	cat <<EOF > /usr/share/JoystickXbox360/xboxdrv.conf
--evdev-absmap ${var[0]}=x1,${var[1]}=y1,${var[2]}=x2,${var[3]}=y2,${var[4]}=dpad_x,${var[5]}=dpad_y --axismap X1=X1,X2=X2,Y1=Y1,Y2=Y2,DPAD_X=DPAD_X,DPAD_Y=DPAD_Y --evdev-keymap ${var[6]}=y,${var[7]}=b,${var[8]}=a,${var[9]}=x,${var[10]}=lb,${var[11]}=rb,${var[12]}=lt,${var[13]}=rt,${var[14]}=back,${var[15]}=start,${var[16]}=tl,${var[17]}=tr --mimic-xpad --silent
EOF
	;;
	*)
	texto="Configuração cancelada..."
	cont="$[${#texto} + 4]"
	dialog --infobox "$texto" 3 $cont
	sleep 3
	clear
	sudo chown root:root /usr/share/JoystickXbox360/*.log
	sudo chown root:root /usr/share/JoystickXbox360/*.conf
	sudo service joystickxbox360 restart 
	exit 0
	;;
esac
configuracao="opção $xbox selecionada: $(cat /usr/share/JoystickXbox360/status.conf)"
cont="$[${#configuracao} + 4]"
joystickconf="$(cat /usr/share/JoystickXbox360/xboxdrv.conf)"
clear
dialog --infobox "Configuração sendo iniciada...\n$configuracao" 4 $cont
sudo chmod 775 /dev/input/event$jost
sudo xboxdrv --evdev /dev/input/event$jost $joystickconf > /usr/share/JoystickXbox360/joystick1.log &
sudo rm /usr/share/JoystickXbox360/joystick1.log
sleep 5
i=0
while true
do
	udevadm info -a -n /dev/input/event$i > /usr/share/JoystickXbox360/joystick.log
	if ! [ "$(cat /usr/share/JoystickXbox360/joystick.log)" ]; then
		clear
		texto="Porta do joystick Xbox 360 emulado não localizada..."
		cont="$[${#texto} + 4]"
		dialog --infobox "$texto" 3 $cont
		sleep 3
		clear
		echo -e "Joystick Xbox 360\033[31;1m falhou\033[0m..." >		 /usr/share/JoystickXbox360/joystickxbox360.conf
		exit 1
	fi
	udevadm info -a -n /dev/input/event$i | grep -q "Microsoft X-Box 360 pad"
	if [ "$?" = "0" ]; then
		dialog --infobox "Porta do joystick Xbox 360 emulado localizada..." 3 52
		echo -e "Joystick Xbox 360\033[32;1m iniciado\033[0m..." >		 /usr/share/JoystickXbox360/joystickxbox360.conf
		jost1=$i
		break
	fi
	i=$[ i + 1 ]
done
sudo chown root:root /usr/share/JoystickXbox360/*.log
sudo chown root:root /usr/share/JoystickXbox360/*.conf
sudo chmod 775 /dev/input/event$jost1
sleep 6
clear
sudo service joystickxbox360 status
sleep 6
clear
dialog --nocancel --pause "Teste o Joystick Xbox 360 emulado no AntiMicroX caso\n
os analógicos ficarem com sentido invertido, use o aplicativo 'Muda a configuração do joystick Xbox 360': \n
opção escolhida agora - Opção $xbox." 11 65 20

reset
antimicrox

exit 0

