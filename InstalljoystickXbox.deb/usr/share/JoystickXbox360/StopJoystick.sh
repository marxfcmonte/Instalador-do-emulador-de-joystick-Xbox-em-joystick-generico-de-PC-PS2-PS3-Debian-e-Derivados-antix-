#!/bin/bash

pasta_joystick=/usr/share/JoystickXbox360

pkill xboxdrv &
sleep 2
echo -e "Joystick Xbox 360\033[31;1m parado\033[0m..." > $pasta_joystick/joystickxbox360.conf
echo -e "Joystick Xbox 360\033[31;1m parado\033[0m..."
sleep 2

exit 0

